Execute proj1.py file in any python IDE
Enter the size of input and nature of input 
You will find the comparison of sorting algorithms with timetaken and a respective graph 