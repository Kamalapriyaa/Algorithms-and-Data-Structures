import random
import time


def generateRandomNumber(size):
    input = []
    for n in range(size):
        input.append(random.randint(1, inputSize))
    return input


def insertionSort(numbers):
   for i in range(1, len(numbers)):
       if numbers[i] >= numbers[i - 1]:
           continue
       for j in range(i):
           if numbers[i] < numbers[j]:
               numbers[j], numbers[j + 1:i + 1] = numbers[i], numbers[j:i]
               break


def merge(left, right):
    if len(left) == 0:
        return right
    if len(right) == 0:
        return left
    final = []
    index_l = index_r = 0
    while len(final) < len(left) + len(right):
        if left[index_l] <= right[index_r]:
            final.append(left[index_l])
            index_l += 1
        else:
            final.append(right[index_r])
            index_r += 1
        if index_r == len(right):
            final += left[index_l:]
            break
        if index_l == len(left):
            final += right[index_r:]
            break
    return final


def mergeSort(array):
    if len(array) < 2:
        return array
    midpoint = len(array) // 2
    return merge(
        left=mergeSort(array[:midpoint]),
        right=mergeSort(array[midpoint:]))



def heapify(arr, n, i):
    largest = i
    left = 2 * i + 1
    right = 2 * i + 2
    if left < n and arr[largest] < arr[left]:
        largest = left
    if right < n and arr[largest] < arr[right]:
        largest = right
    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]
        heapify(arr, n, largest)


def heapSort(numbers):
    n = len(numbers)
    for i in range(n // 2 - 1, -1, -1):
        heapify(numbers, n, i)
    for i in range(n - 1, 0, -1):
        numbers[i], numbers[0] = numbers[0], numbers[i]
        heapify(numbers, i, 0)
    
def subPartition(array, start, end, array_pivot):
    if not (start <= array_pivot <= end):
        raise ValueError('idx pivot must be between start and end')
    array[start], array[array_pivot] = array[array_pivot], array[start]
    pivot = array[start]
    i = start + 1
    j = start + 1
    while j <= end:
        if array[j] <= pivot:
            array[j], array[i] = array[i], array[j]
            i += 1
        j += 1
    array[start], array[i - 1] = array[i - 1], array[start]
    return i - 1

def quickSort(array, start=0, end=None):
    if end is None:
        end = len(array) - 1
    if end - start < 1:
        return
    array_pivot = random.randint(start, end)
    i = subPartition(array, start, end, array_pivot)
    quickSort(array, start, i - 1)
    quickSort(array, i + 1, end)

def partition(arr, low, high):
    mid = (low + high)//2
    if arr[mid] < arr[low]:
        arr[low], arr[mid] = arr[mid], arr[low]
    if arr[high] < arr[low]:
        arr[high], arr[low] = arr[low], arr[high]
    if arr[mid] < arr[high]:
        arr[high], arr[mid] = arr[mid], arr[high]

    i = low
    pivot = arr[high]

    for j in range(low, high):
        if arr[j] < pivot:
            arr[i], arr[j] = arr[j], arr[i]
            i = i + 1
    arr[i], arr[high] = arr[high], arr[i]
    return i

def mQuickSort(arr, low, high):
    if len(arr) == 1:
        return arr
    if len(arr) == 2:
        if arr[high] < arr[low]:
            arr[high], arr[low] = arr[low], arr[high]
        return arr
    if low < high:
        pi = partition(arr, low, high)
        mQuickSort(arr, low, pi - 1)
        mQuickSort(arr, pi + 1, high)


def medianQuickSort(arr):
    mQuickSort(arr, 0, len(arr)-1)




isContinue = 1
while isContinue == 1:
    inputSize = int(input("Enter input size of numbers to sort (eg: 100,500,1000..)\n"))
    choice = int(input("Enter your choice: \n1.Sorting of random numbers. \n2.Sorting inputs that are already sorted. \n3.Sorting inputs that are reversely sorted.\n"))
    inputList = generateRandomNumber(inputSize)

    inputArr = inputList
    if choice == 2:
        inputArr = sorted(inputList)
    elif choice == 3:
        inputArr = sorted(inputList, reverse=True)



    #-----------------------INSERTION SORT-----------------------#
    start = time.time()
    insertionSort(inputArr.copy())
    end = time.time()
    i_sort = end-start
    print("Running time of Insertion Sort:", end - start, "secs")



    #-----------------------MERGE SORT-----------------------#
    start = time.time()
    mergeSort(inputArr.copy())
    end = time.time()
    m_sort = end-start
    print("Running time of Merge Sort:", end - start, "secs")



    #-----------------------HEAP SORT-----------------------#
    start = time.time()
    heapSort(inputArr.copy())
    end = time.time()
    h_sort = end-start
    print("Running time of Heap Sort:", end - start, "secs")



    #-----------------------QUICK SORT-----------------------#
    start = time.time()
    quickSort(inputArr.copy())
    end = time.time()
    q_sort = end-start
    print("Running time of Quick Sort:", end - start, "secs")



    #-----------------------MEDIAN QUICK SORT(MEDIAN = 3)-----------------------#
    if inputSize <= 10:
        print("Calling Insertion sort since array size is less than or equal to 10\n")
        start = time.time()
        insertionSort(inputArr.copy())
        end = time.time()
        mq_sort = end-start
        print("Running time of Insertion Sort :", end - start, "secs")
    else:
        start = time.time()
        medianQuickSort(inputArr.copy())
        end = time.time()
        mq_sort = end-start
        print("Running time of Quick Sort(median=3):", end - start, "secs")
        
    import matplotlib.pyplot as plt
    import numpy as np
    x = ['Insertion\nSort','Merge\nSort','Heap\nSort','Quick\nSort','Median\nQuickSort']
    a = [i_sort,m_sort,h_sort,q_sort,mq_sort]
    gph=plt.subplot()
    gph.set_xticks(range(5))
    gph.set_xticklabels(x)
    plt.ylabel('Time in seconds')
    gph.plot(x,a,linestyle='--', marker='o')
    plt.show()

    isContinue = bool(input("Do you want to continue? 1/0\n"))
