Steps for execution and output:

1. Script name: shortestPathAlgo.py 
2. Please use Python 3.6 or above
3. This script will automatically take 4 input files as input : input0.txt, input1.txt, input2.txt, input3.txt
4. The Script itself will display the shortest path for each node
5. Please place all the input files in the path from where you are invoking the .py script


Input File Format: Same as given in project 2 requirement
First Line: 
value1 : no.of.vertices
value2: no.of. edges
value3: Graph type: directed graph D (or) Undirected grap U

Last Line: Metion the source vertex here

Rest of the lines are path and its cost